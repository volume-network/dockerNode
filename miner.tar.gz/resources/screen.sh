#!/bin/sh 
cd "$(dirname "$0")" 
screen -dmS creep ./run.sh
