﻿using System.Windows;

namespace ConfigEditor
{
	/// <summary>
	/// Interaction logic for App.xaml
	/// </summary>
	public partial class App : Application
    {
    }
}
